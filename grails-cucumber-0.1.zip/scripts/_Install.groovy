ant.mkdir(dir:"${basedir}/test/features")
ant.mkdir(dir:"${basedir}/test/features/step_definitions")
ant.mkdir(dir:"${basedir}/test/features/support")
ant.mkdir(dir:"${basedir}/target")
